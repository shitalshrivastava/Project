
import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Users from "./users";
import Posts from "./post/postData";
import User from "./user";
import PostDetails from "./post/postDetails"
import TodoData from "./User/TodoData"
 
function Routing() {
  return (
    <Switch> 
      <Route path="/users"  component={Users} />     
      <Route path="/user" component={User}/>
      <Route path="/post/postData" component={Posts}/>      
      <Route path="/post/postDetails" component={PostDetails}/>
    </Switch>
  );
}
export default Routing;
