import React from "react"
import userDetails from "../user";
import { Link } from "react-router-dom"

//import {Link} from "react-router-dom"

class PostDetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            postDetails: [],
            postDetailsNo: 0
        }
    }

    setfocus(){
        var tbfocus= document.getElementById('tb1').focus();
        return tbfocus;
    }

    componentDidMount() {
        this.setfocus()
        const post = this.props.location.state.post;
        const url = "https://jsonplaceholder.typicode.com/comments?postId=" + post.id
        fetch(url)
            .then(response => response.json())
            .then(data => {
                this.setState({
                    postDetails: data
                });
            })
        /*const { todoDetails } = this.state;
        this.setState({
            todoNo: todoDetails.length
        })*/
        
    }
    render() {

        const { fromPath } = this.props.location.state;
        this.state.postDetailsNo = this.state.postDetails.length

        
        const PostdetailsData = this.state.postDetails.map(PostdetailsData => {
            return <tr key={PostdetailsData.id}>
               <td><strong>From:</strong>{PostdetailsData.name}, <strong>Email:</strong>{PostdetailsData.email}</td> 
               <td>{PostdetailsData.body}</td>              
                    
            </tr >

        });

        return (

            <div className="container" >
                <div className="card">
                    <h3 className="h3">Total:{this.state.postDetailsNo}</h3>
                    <div><h3 className="banner">Post Details</h3></div>
                    <div className="card-body">
                        <table id="tb1" className="table table-bordered">
                            <tbody>
                                
                                        {PostdetailsData}

                                    
                            </tbody>
                        </table>

                    </div>
                    <div className="card-footer">
                        <Link className="btn btn-primary" to={fromPath}>Go back</Link>
                    </div>
                </div>
            </div>

        )


    }
}
export default PostDetails;