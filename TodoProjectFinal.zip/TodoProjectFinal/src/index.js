import React from 'react';
import ReactDOM from 'react-dom';
import Users from './users';
import {BrowserRouter as Router} from 'react-router-dom';
import Routing from "./Routing";

function App(){
    return(
        <Router>
            <div>
                <Users/>
            </div>
            <div>
                <Routing/>
            </div>
        </Router>
    )
}

ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
//serviceWorker.unregister();
