import React from "react"
import {Route,Switch} from "react-router-dom"
import Users from "./users";
import UserDetails from "./user";
import PostDetails from "./post/postData";

export default class Routing extends React.Component{
render(){
    
        return (

            <Switch>
                    <Route path="/" component={Users} exact/>
                    <Route path="/users" component={Users}/>
                    <Route path="/post/postData" component={PostDetails}/>
                    <Route path="/user" component={UserDetails}/>
            </Switch>

                  
    )
}
}



