import React from 'react'
import { Link } from 'react-router-dom'


class userDetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            todoDetails: [],
            todoNo: 0,
            notcompleted: [],
            toDoList: []
        }
        this.handleCheck = this.handleCheck.bind(this);
        this.updateArray = this.updateArray.bind(this);
    }

    componentDidMount() {
        console.log('User.js - Did Mount');
        const user = this.props.location.state.user;
        const url = "https://jsonplaceholder.typicode.com/todos?userId=" + user.id
        //const url = "https://jsonplaceholder.typicode.com/todos?userId=" + user.id;
        fetch(url)
            .then(response => response.json())
            .then(data => {
                console.log(data);
                this.setState({
                    todoDetails: data
                });
            });
       

    }

    /* getToDoList = (flag) => {
         const { todoDetails } = this.state;
         if(flag === false){
             const toDoList = todoDetails.map( item => {
                 if (flag === false) {
                     return <tr key={item.id}>
                         <td>
                            :---{item.title}
                         </td>
                         <td> {item.completed}</td>
                     </tr>
                 }
             });
             /* this.setState({
                 ...this.state, toDoList: toDoList
             }); 
             return toDoList;
         }
     }*/

    handleCheck(e) {


        /* const TodoDetails= this.state.todoDetails.map( complete => {
            if(complete.completed === false){

            }
        }
        const TodoDetails= this.state.todoDetails.map(todo=>{
            return <tr>
                <td>
                    {todo.title}

                </td>*/




    }

    updateArray() {
        console.log("hello from updatearray");
     var newArray = this.state.todoDetails.filter(function (complete) {
            return complete.completed === false;
        })
        console.log("newArray", newArray);

        
    }







    render() {
        this.state.todoNo = this.state.todoDetails.length;
        const { fromPath } = this.props.location.state;

        const TodoDetails = this.state.todoDetails.map(todo => {
            return <tr key={todo.id}>

                <td>
                    {todo.title}

                </td>



            </tr>
        })
        // const TodoDetails = this.getToDoList(false);
        /*const TodoDetails= this.state.todoDetails.map(todo=>{
              return <tr key={todo.id}>
                  <td>
                      {todo.title}
  
                  </td>
                  </tr>
          }*/



        return (

            <div className="container" >
                <h3>Number of Todo's:{this.state.todoNo}</h3>
                <input type="checkbox" onChange={this.handleCheck} />View all
            <div className="card">
                    <div className="card-header">Todo's</div>
                    <div className="card-body">

                        <table className="table">
                            <tbody>
                                {TodoDetails}
                                {/* <tr>
                                <td>
                                </td>
                               
                            </tr> */}
                            </tbody>
                        </table>

                    </div>
                    <div className="card-footer">
                        <Link className="btn btn-primary" to={fromPath}>Go back</Link>
                    </div>
                </div>
            </div>
        )
    }
}
export default userDetails;